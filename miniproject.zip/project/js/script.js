
var quotes = [
  { quote: 'The purpose of oue lives is to be happy'},
 { quote: "Live Long and Prosper"},
  { quote: "Difficult roads often lead to beautiful destinations"},
  { quote: 'We are what we pretend to be, so we must be careful about what we pretend to be.'}
]
console.log(quotes);

function getRandomQuote() {
  var random = Math.floor(Math.random() * quotes.length);
  return(quotes[random ]);
}


function printQuote(){
  var currentQuote = getRandomQuote();
  var html = ''
  var quoteDiv = document.getElementById('quote-box')

  html += '<p class="quote">' + currentQuote.quote 
  
  if ('tags' in currentQuote){
  
      html += '  ' + currentQuote.tags.join(', ')
  }
  
  html += '</p>'

  quoteDiv.innerHTML = html
  setRandomBackground()
  
}

function setRandomBackground(){
  
  var randomNumber = Math.floor(Math.random() * 6)
  
  if (randomNumber == 0){
    document.body.style.background = 'black';
  }else if (randomNumber == 1){
    document.body.style.background = 'black';
  }else if (randomNumber == 2){
    document.body.style.background = 'black';
  }else if (randomNumber == 3){
    document.body.style.background = 'black';
  }else if (randomNumber == 4){
    document.body.style.background = 'black';
  }else if (randomNumber == 5){
    document.body.style.background = 'black';
  }
}

document.getElementById('load-quote').addEventListener("click", printQuote, false);
window.setInterval(printQuote, 30000);